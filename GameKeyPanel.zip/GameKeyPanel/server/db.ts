
// JSON File Storage - No database connection needed
// All data is stored in local JSON files in the /data directory

export const db = null; // Not used with JSON storage
